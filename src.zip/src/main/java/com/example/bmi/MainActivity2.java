package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class MainActivity2 extends AppCompatActivity {
    TextView t1,t2,t3,t4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        t1=(TextView)findViewById(R.id.textView6) ;
        String result =getIntent().getStringExtra("message_key");
        t1.setText(result);

        t2=(TextView) findViewById(R.id.height);
        String result1 =getIntent().getStringExtra("message_key1");
        t2.setText(result1);

        t3=(TextView) findViewById (R.id.weight) ;
        String result2 =getIntent().getStringExtra("message_key2");
        t3.setText(result2);

        t4=(TextView) findViewById(R.id.age);
        String result3 =getIntent().getStringExtra("message_key3");
        t4.setText(result3);

    }
}