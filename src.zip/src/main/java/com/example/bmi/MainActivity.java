package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {



    EditText h;
    EditText w;
    EditText a;
    Button cal;
    String resultant;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        h=(EditText) findViewById(R.id.editTextTextPersonName);
        w=(EditText) findViewById(R.id.editTextTextPersonName2);
        a=(EditText) findViewById(R.id.editTextTextPersonName3);
        cal=(Button) findViewById(R.id.button5);

    cal.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            String height= h.getText().toString();
            String weight= w.getText().toString();
            String age=a.getText().toString();





            float weightValue=Float.parseFloat(weight);
            float heightValue=Float.parseFloat(height)/100;
            float BMI=weightValue / (heightValue * heightValue);
//                if(height.length()==0 || weight.length()==0)
//                {
//                    Toast.makeText(MainActivity.this, "height and weight should not be empty !",
//                            Toast.LENGTH_LONG).show();
//                }


            if (BMI < 15){
                resultant =("Very severely underweight");
            }
            else if (BMI >= 15 && BMI < 16){
                resultant =("Severely underweight");
            }
            else if (BMI >=16 && BMI < 18.5){
                resultant =( "Underweight" );
            }
            else if (BMI >=18.5 && BMI < 25){
                resultant =("Normal");
            }
            else if (BMI >= 25 && BMI < 30){
                resultant =("Overweight");
            }
            else if (BMI>=30 && BMI < 35 ){
                resultant =( "Obese Class 1 - Moderately Obese" );
            }
            else if (BMI>= 35 && BMI < 40){
                resultant =( "Obese Class 2 - Severely Obese" );
            }
            else {
                resultant = ("Obese Class 3 - Very Severely Obese");
            }





            // Create the Intent object of this class Context() to Second_activity class
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            // now by putExtra method put the value in key, value pair key is
            // message_key by this key we will receive the value, and put the string





            intent.putExtra("message_key", resultant);
            intent.putExtra("message_key1",height);
            intent.putExtra("message_key2",weight);
            intent.putExtra("message_key3",age);

            // start the Intent
            startActivity(intent);


        }
    });
    }
}